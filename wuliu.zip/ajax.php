<?php
/** 
  * 获取物流信息
  * @author LF. <24677102@qq.com> 
  * @request http://blog.itie.pro/
  * @param string $Exp_id 快递单号 $Exp_code 快递识别码，没有默认自动识别
  * @return url
**/ 
	header('Content-Type: text/html; charset=UTF-8');
	error_reporting(0);

	$Exp_id = $_POST['nu'];
	/*$Exp_code = $_POST['code'];*/

    //接口
	/* $url = 'https://m.kuaidi100.com/query?type='.$Exp_code.'&postid='.$Exp_id; */
	$url = 'https://sp0.baidu.com/9_Q4sjW91Qh3otqbppnN2DJv/pae/channel/data/asyncqury?appid=4001&nu='.$Exp_id;

    //创建cookie目录文件
    $cookie = tempnam(sys_get_temp_dir(), 'cookie');;
    $t = parse_url($url);

    //获取cookie并写入
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, "$t[scheme]://$t[host]/");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    curl_exec($curl);

    //使用接口
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    $data = curl_exec($curl);
    curl_close($curl);
    
    //转换给前端需要的格式并输出
    $odata = json_decode($data, 1);
    $retjson = $odata;
    echo json_encode($retjson,JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>