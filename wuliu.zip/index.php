<?php
	/*
	  Author：雾里看雪
	  QQ：24677102
	*/
	$title = '快速查询物流';
	$kfqq = '123456789';
	$site_name = '站点后缀';
	$site_url = '//你的域名/';
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=0.9, maximum-scale=0.9" />
		<title><?=$title?></title>
		<link rel="stylesheet" type="text/css" href="//www.layuicdn.com/layui/css/layui.css" />
		<link href="//www.qq-admin.cn/assets/css/main.css" rel="stylesheet">
		<link href="//lib.baomitu.com/twitter-bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
		<link href="//lib.baomitu.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
		<style>
		body{
			background:url(https://pic2.superbed.cn/item/5d4cb3f1451253d17803a793.png);
		}
		</style>
	</head>
	<body>
		<div class="pagetop" style="">
			<div class="container">
				<div class="row">
					<div class="text-right">
						<div class="index-buttons">
							<button onclick="kf();" type="reset" class="btn btn-xs btn-blue">客服</button>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="layui-container">
			<div class="layui-row">
				<div id="logo">
					<br /><br /><center>
						<img src="images/logo.png"  height="100" width="250" />
					</center><br />
				</div>
				<form class="layui-form" action="">
					<div class="col-lg-8 col-md-12 col-lg-offset-2 text-center" role="main"> 
						<div class="panel panel-info"> 
							<div class="panel-body text-center"> 
								<div class="layui-form-item">
									<div class="form-group">
										<div class="col-sm-12">
											<input type="text" id="nu" name="nu" lay-verify="required" class="form-control"  placeholder="请输入运单号" required=required>
										</div>
									</div>
								</div>
								<button class="layui-btn" lay-submit lay-filter="formDemo">查询</button>
								&nbsp;&nbsp;&nbsp;or&nbsp;
								<button onclick="resets();" type="reset" class="layui-btn layui-btn-primary">重置</button>
							</div> 
						</div> 
					</div> 
				</form>
				<br><br>
				<div class="col-lg-8 col-md-12 col-lg-offset-2">
					<div id="resultbox" style="background: rgba(0, 0, 0, 0.15);">
						<ul id="msg" class="layui-timeline">
						</ul>
					</div>
				</div>
			</div>
		</div><br /><br /><br /><br /><br />
		<footer class="main-footer">
			<div class="container">
				<div class="row">
					<div class="col-sm-8">
						<div class="widget">
							<h4 class="title">
								关于本站
							</h4>
							<div class="content tag-cloud">
								<?=$title?>为起点网络旗下网站，创建于2017年8月，本网站集合各大平台物流接口，欢迎您的使用。
							</div>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="widget">
							<h4 class="title">
								获取帮助
							</h4>
							<div class="content tag-cloud">
								<ul>
									<li><a onclick="ad();">投放广告</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						© 2017-2019 
						<a target="_blank" href="<?=$site_url?>"><?=$title?></a>
						<a target="_blank" href="<?=$site_url?>"><?=$site_name?></a>
					</div>
				</div>
			</div>
		</div>
		<div style="position: fixed;right: 0;bottom: 0;width: 65px;height: 65px;z-index: 99;">
			<img src="https://static.myssl.com/res/images/myssl-id.png" alt="" style="width:100%;height:100%" />
		</div>
		<script src="//lib.baomitu.com/jquery/2.2.4/jquery.min.js"></script>
		<script language="javascript" src="//www.layuicdn.com/layui/layui.js"></script>
		<script>
			function ad(){
				layer.open({
					type: 1,
					title: '广告投放',
					skin: 'layui-layer-demo', //样式类名
					closeBtn: 1, //不关闭按钮样式
					anim: 2,
					shadeClose: true, //开启遮罩关闭
					content: '<div style="background-color:#FF9900;padding: 3px;">\
								<img border="0" width="32" src="https://pic.superbed.cn/item/5d4cb440451253d17803ae4b.gif">&nbsp;&nbsp;需要投放广告请联系QQ：<?=$kfqq?>\
							  </div>\
							  <div style="background-color:#55D5A4;padding: 3px;">\
								<img border="0" width="32" src="https://pic.superbed.cn/item/5d4cb440451253d17803ae4b.gif">&nbsp;&nbsp;拒接黄色、赌博、毒品、军火等违反法律的广告\
							  </div>'
				});
			}
			function kf(){
				layer.open({
					type: 2,
					title: '联系站长',
					shadeClose: true,
					shade: 0.8,
					area: ['20%', '20%'],
					content: ['http://wpa.qq.com/msgrd?v=3&uin=<?=$kfqq?>&site=qq&menu=yes','no']
				}); 
			}
			function resets(){
				$('#resultbox ul').html('');
				layer.msg('重置成功');
			}
			layui.use('form', function(){
				var form = layui.form;
				var $ = layui.jquery;
				form.on('submit(formDemo)', function(data){
					var load = layer.load(1, {shade: [0.1,'#fff']}); //加载动画_开始
					$.post('ajax.php',data.field,function(res){
						var str = '';
						if(res.status==0){
							$.each(res.data.info.context,function(k,v){
								str += '<li class="layui-timeline-item">\n' +
									'                        <i class="layui-icon layui-timeline-axis"></i>\n' +
									'                        <div class="layui-timeline-content layui-text">\n' +
									'                            <p>'+v.desc+'_[时间不显示问题正在修复]</p>\n' +
									'                        </div>\n' +
									'</li>\n';
							});
							layer.alert('查询成功，祝您生活愉快~',{
								icon: 1,
								skin: 'layer-ext-moon'
							})
							$('#resultbox ul').html(str);
							/*layer.open({
								type: 1,
								skin: 'layui-layer-rim', //加上边框
								area: ['720px', '540px'], //宽高
								content: str
							});*/
						}else{
							layer.alert('查询失败，请检查后重试~',{
								icon: 2,
								skin: 'layer-ext-moon'
							})
							str += ' <li class="layui-timeline-item">\n' +
								'                        <i class="layui-icon layui-timeline-axis"></i>\n' +
								'                            <div class="layui-timeline-content layui-text">\n' +
								'                            <h3 class="layui-timeline-title">错误信息:</h3>\n' +
								'                            <p>code:'+res.status+'</p>\n' +
								'                            <p>msg:'+res.msg+'</p>\n' +
								'                        </div>\n' +
								'</li>\n';
							$('#resultbox ul').html(str);
							/*layer.open({
								type: 1,
								skin: 'layui-layer-rim', //加上边框
								area: ['720px', '540px'], //宽高
								content: str
							});*/
						}
					},'json');
					layer.close(load); //加载动画_结束
					return false;
				});
			});
		</script>
	</body>
</html>